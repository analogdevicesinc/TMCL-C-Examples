/*******************************************************************************
* Copyright © 2024 Analog Devices, Inc.
*******************************************************************************/

#ifndef TMC5271_SIMPLE_ROTATION_H_
#define TMC5271_SIMPLE_ROTATION_H_

#include "TMC5271.h"

void initAllMotors(uint16_t icID);

#endif
